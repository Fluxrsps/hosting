package dev.or2.central.account

import java.time.LocalDateTime

public data class CharacterData(
    public val characterId: Int,
    public val displayName: String?,
    public val previousDisplayName: String?,
    public val displayNameChangedAtMillis: Long?,
    public val members: Boolean,
    public val worldId: Int?,
    public val coordX: Int,
    public val coordZ: Int,
    public val coordLevel: Int,
    public val varps: Map<Int, Int>,
    public val createdAt: LocalDateTime?,
    public val lastLogin: LocalDateTime?,
    public val lastLogout: LocalDateTime?,
    public val mutedUntil: LocalDateTime?,
    public val bannedUntil: LocalDateTime?,
    public val runEnergy: Int,
    public val xpRate: Double,
    public val attrs: Map<String, Any>,
    public val onlineCentralWorldId: Int? = null,
    public val onlineSessionHeartbeat: LocalDateTime? = null,
    public val gameMode: GameModes,
    public val donatorRank: DonatorRanks
)

/**
 * Account row fields plus the loaded [account_characters] row ([characterData]).
 */
public data class AccountData(
    public val accountId: Int,
    public val accountName: String,
    public val rights: Rights,
    public val email: String?,
    public val discordId: Long? = null,
    public val knownDevice: Int? = null,
    public val trustedDevices: List<TrustedDeviceData> = emptyList(),
    public val twoFactorAuth: TwoFactorAuthData = TwoFactorAuthData(),
    public val characterData: CharacterData,
)
