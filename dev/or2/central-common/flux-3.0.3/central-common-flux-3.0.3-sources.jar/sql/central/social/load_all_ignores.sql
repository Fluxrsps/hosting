SELECT owner_character_id, ignored_character_id
FROM character_ignores
