SELECT COUNT(*) FROM sessions
