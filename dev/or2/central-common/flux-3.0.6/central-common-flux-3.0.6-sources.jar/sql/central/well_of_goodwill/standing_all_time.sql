-- A character's donated total across every cycle, and the rank that goes with it.
SELECT d.total AS amount,
       (SELECT COUNT(*) + 1
        FROM (SELECT SUM(amount) AS s
              FROM well_of_goodwill_donations
              GROUP BY character_id) o
        WHERE o.s > d.total) AS rank
FROM (SELECT COALESCE(SUM(amount), 0) AS total
      FROM well_of_goodwill_donations
      WHERE character_id = ?) d
