-- A character's donated total for one cycle, and the rank that goes with it.
SELECT COALESCE(d.amount, 0) AS amount,
       CASE
           WHEN COALESCE(d.amount, 0) = 0 THEN 0
           ELSE (SELECT COUNT(*) + 1
                 FROM well_of_goodwill_donations o
                 WHERE o.cycle_id = ? AND o.amount > d.amount)
       END AS rank
FROM (SELECT amount FROM well_of_goodwill_donations WHERE cycle_id = ? AND character_id = ?) d
